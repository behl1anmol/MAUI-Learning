﻿namespace MonkeyFinder.Services
{
    public class MonkeyService
    {
    }
}
