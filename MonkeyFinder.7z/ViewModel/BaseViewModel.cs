﻿namespace MonkeyFinder.ViewModel
{
    public class BaseViewModel
    {
    }
}
