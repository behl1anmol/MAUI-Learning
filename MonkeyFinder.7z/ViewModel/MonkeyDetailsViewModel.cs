﻿namespace MonkeyFinder.ViewModel
{
    public class MonkeyDetailsViewModel
    {
    }
}
