﻿namespace MonkeyFinder.ViewModel
{
    public class MonkeyViewModel
    {
    }
}
